public class Admin extends Usuario {

    public Admin(String userName, String password) {

        super(userName, password);

    }

    public Admin() {}

    @Override
    public String toString() {
        return super.toString();
    }
}
