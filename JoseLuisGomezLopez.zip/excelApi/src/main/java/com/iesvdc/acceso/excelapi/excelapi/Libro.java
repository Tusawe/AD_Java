/*
 */
package com.iesvdc.acceso.excelapi.excelapi;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

/**
 * Esta clase almacena información de libros para generar ficheros de Excel. Un
 * libro se compone de hojas.
 * 
 * @author profesor
 */
public class Libro {
    private List<Hoja> hojas;
    private String nombreArchivo;

    public boolean compare(Libro copia) {
        // si tienen mismo número hojas
        // para cada hoja compara this.hoja(x) con copia.hoja(x)
        if (this.hojas.size() == copia.hojas.size()) {
            for (int i = 0; i < this.hojas.size(); i++) {
                if (!this.hojas.get(i).compare(copia.hojas.get(i))) {
                    System.out.println("Hojas diferentes");
                    return false; // hay una hoja con datos diferentes
                }
            }
        } else {
            System.out.println("Distinto número de hojas");
            return false; // distinto número de hojas
        }
        System.out.println("Libros iguales");
        return true; // todas las hojas con mismo nombre y contenido
    }

    public Libro() {
        this.hojas = new ArrayList<>();
        this.nombreArchivo = "nuevo.xlsx";
    }

    public Libro(String nombreArchivo) {
        this.hojas = new ArrayList<>();
        this.nombreArchivo = nombreArchivo;
    }

    public String getNombreArchivo() {
        return nombreArchivo;
    }

    public void setNombreArchivo(String nombreArchivo) {
        this.nombreArchivo = nombreArchivo;
    }

    public boolean addHoja(Hoja hoja) {
        return this.hojas.add(hoja);
    }

    public Hoja removeHoja(int index) throws ExcelAPIException {
        if (index < 0 || index > this.hojas.size()) {
            throw new ExcelAPIException("Libro::removeHoja(): Posición no válida.");
        }
        return this.hojas.remove(index);
    }

    public Hoja indexHoja(int index) throws ExcelAPIException {
        if (index < 0 || index > this.hojas.size()) {
            throw new ExcelAPIException("Libro::indexHoja(): Posición no válida.");
        }
        return this.hojas.get(index);
    }

    public void load() {
        
        System.out.println("Cargando libro:");
        try (FileInputStream fis = new FileInputStream("test.xlsx")){
            XSSFWorkbook wb = new XSSFWorkbook(fis);
            int nhojas= wb.getNumberOfSheets();
            // CREAR LIBRO
            Libro libro = new Libro("test1.xlsx"); 

            for (int i = 0; i < nhojas; i++) {
                XSSFSheet hojaExcel = wb.getSheetAt(i); 
                int nfilas = hojaExcel.getLastRowNum();
                short maxCol=0;
                for (int j = hojaExcel.getFirstRowNum(); j < nfilas; j++) {
                    if (maxCol < hojaExcel.getRow(j).getLastCellNum()) {
                        maxCol=hojaExcel.getRow(j).getLastCellNum();
                    }
                }
                // CREAR HOJA
                maxCol++; // si estamos en la posición maxCol, tenemos maxCol+1 columnas
                nfilas++; // si estamos en la posición nfilas, tenemos nfilas+1 filas
                Hoja hoja = new Hoja(hojaExcel.getSheetName(),nfilas,maxCol);
                hoja.fill(""); // rellenamos la hoja con la cadena vacía

                System.out.println("Estamos en la hoja: " + i 
                    + " que tiene: " + nfilas+" filas.");
                for (int j = hojaExcel.getFirstRowNum(); j < nfilas; j++) {
                    XSSFRow filaExcel = hojaExcel.getRow(j);
                    System.out.println("Estoy en la fila: " + j );
                    int nceldas = filaExcel.getLastCellNum();
                    for (int k = filaExcel.getFirstCellNum(); k < nceldas; k++) {
                        XSSFCell celdaExcel = filaExcel.getCell(k);
                        System.out.println("Contenido de la celda posición fila=" + j +" col=" + k + " = " + celdaExcel.getStringCellValue());
                        // METER DATOS EN HOJA
                        hoja.setDato(celdaExcel.getStringCellValue(), j, k);
                    }
                    
                }
                libro.addHoja(hoja);
            }
            wb.close();
            libro.save();
        } catch (IOException | ExcelAPIException ex) {
            // Logger.getLogger(HolaMundoExcel.class.getName()).log(Level.SEVERE, null, ex);
            System.out.println("ERROR al crear el archivo: "+
                    ex.getLocalizedMessage());
        }

    }
    
    public void load(String filename){
        this.nombreArchivo = filename;
        this.load();
    }
    
    public void save() throws ExcelAPIException{
        SXSSFWorkbook wb = new SXSSFWorkbook();
        
        for (Hoja hoja: this.hojas) {
            Sheet sh = wb.createSheet(hoja.getNombre());
            for (int i = 0; i < hoja.getFilas(); i++) {
                Row row = sh.createRow(i);
                for (int j = 0; j < hoja.getColumnas(); j++) {
                    Cell cell = row.createCell(j);
                    cell.setCellValue(hoja.getDato(i, j));                
                }
            }
        }
        try (FileOutputStream out = new FileOutputStream(this.nombreArchivo)){            
            wb.write(out);
            // out.close();                        
        } catch (IOException ex) {
            throw new ExcelAPIException("Error al guardar el archivo");
        } finally {
            wb.dispose();
        }
    }
    
    public void save(String filename) throws ExcelAPIException{
        this.nombreArchivo = filename;
        this.save();
    }
    
    // private void testExtension(){
        
    // }
}













