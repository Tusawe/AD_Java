
package app.clasesSecundarias;


public final class TypeISBN{

    public static final int ISBN13 = 13;
    public static final int ISBN10 = 10;
}